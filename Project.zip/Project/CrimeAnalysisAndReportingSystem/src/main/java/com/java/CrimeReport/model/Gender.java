package com.java.CrimeReport.model;

public enum Gender {
	MALE,FEMALE
}
