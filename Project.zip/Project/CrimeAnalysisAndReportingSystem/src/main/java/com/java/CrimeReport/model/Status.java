package com.java.CrimeReport.model;

public enum Status {
	OPEN, CLOSED, UNDER_INVESTIGATION
}
