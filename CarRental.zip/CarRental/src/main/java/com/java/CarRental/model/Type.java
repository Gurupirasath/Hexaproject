package com.java.CarRental.model;

public enum Type {
	DAILYLEASE, MONTHLYLEASE
}

