package com.java.CarRental.model;

public enum Status {
	AVAILABLE,NOTAVAILABLE

}
