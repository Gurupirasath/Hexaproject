package com.java.CarRental.Exception;

public class VehicleNotFoundException extends Exception{
	
	public VehicleNotFoundException(String error){
		super(error);
	}
}
